<template>
  <button></button>
</template>

<script lang="ts" setup></script>
