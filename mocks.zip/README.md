- [ ] Investigar el match entre tsconfig y eslint para la detección de errores.

- [ ] Mercury

- [ ] Unchecked
- [x] Checked
