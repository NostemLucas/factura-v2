export default defineAppConfig({
  ui: {
    colors: {
      primary: 'primary',
      neutral: 'zinc'
    }
  }
})
